
import java.io.*;
import  java.util.*;
import java.lang.*;
/**
 * Created by Owner on 12/5/2015.
 *
 * Lowell Batacan
 */
public class SocialMediaTraversal
{

    private ArrayList<UserObj> DATA_OF_PEOPLE;
    private ArrayList<UserObj> POSSIBLE_LIST;
    public SocialMediaTraversal()
    {
        this.DATA_OF_PEOPLE = new ArrayList<>();
        this.POSSIBLE_LIST = new ArrayList<>();
    }

    public void addPerson(UserObj o)
    {
        this.DATA_OF_PEOPLE.add(o);
    }

    public void findPossFriend(boolean status)
    {
        for(UserObj user:this.DATA_OF_PEOPLE)
        {
            if(user.getStatus() == status)
            {
                this.POSSIBLE_LIST.add(user);
                System.out.println(user.getName());
            }
        }
    }
    public UserObj getFriendFromList(String name)
    {
        UserObj foundUser = null;
        for(UserObj user:this.POSSIBLE_LIST)
        {
            if(user.getName().equalsIgnoreCase(name))
            {
                foundUser = user;
            }
        }
        return foundUser;
    }

    //see if user exists in possible list
    public boolean containsNamePL(String userName)
    {
        boolean truth = false;
        for(UserObj user:this.POSSIBLE_LIST)
        {
            if(user.getName().equalsIgnoreCase(userName))
            {
                truth = true;
            }
        }
        return truth;
    }

    public void contactEveryone(UserObj user)
    {
        for(UserObj eachUser: this.DATA_OF_PEOPLE)
        {
            if(user.isFriends(eachUser))
            {
                eachUser.contact();
                System.out.println(eachUser.getName() + " was contacted");
            }
        }
    }

    public void uncontactEveryone(UserObj user)
    {
        for(UserObj eachUser: this.DATA_OF_PEOPLE)
        {
            if(user.isFriends(eachUser))
            {
                eachUser.unContact();
            }
        }
    }



    }
