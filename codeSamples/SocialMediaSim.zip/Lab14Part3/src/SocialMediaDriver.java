import java.util.*;
import java.lang.*;
import java.text.*;
import java.io.*;

/**
 * Created by Owner on 12/5/2015.
 *
 * Lowell Batacan
 */
public class SocialMediaDriver {
    public static void main(String[] args)
    {
        /*
        Create Dummy Data so User can find some existing friends
         */
        //FriendSet1
        UserObj YukiN = new UserObj("Yuki", false);
        UserObj HaruhiS = new UserObj("Haruhi", true);
        UserObj Kyon = new UserObj("Kyon", true);
        UserObj Asahina = new UserObj("Asahina", false);
        YukiN.setFriendToFriend(HaruhiS);
        YukiN.setFriendToFriend(Kyon);
        YukiN.setFriendToFriend(Asahina);
        HaruhiS.setFriendToFriend(Kyon);
        HaruhiS.setFriendToFriend(Asahina);
        Kyon.setFriendToFriend(Asahina);

        //FriendSet2
        UserObj EdE = new UserObj("Edward", true);
        UserObj AlE = new UserObj("Alfonso", false);
        UserObj RoyM = new UserObj("Roy Mustang", true);
        EdE.setFriendToFriend(AlE);
        EdE.setFriendToFriend(RoyM);
        AlE.setFriendToFriend(RoyM);
        //friendset3
        UserObj MasterC = new UserObj("Master Chief", false);
        UserObj NathanD = new UserObj("Nathan", true);
        UserObj ElenaF = new UserObj("Elena", true);
        MasterC.setFriendToFriend(NathanD);
        MasterC.setFriendToFriend(ElenaF);
        ElenaF.setFriendToFriend(NathanD);
        //friendset4
        UserObj MaribelB = new UserObj("Maribel", true);
        UserObj LouieB = new UserObj("Louie", true);
        MaribelB.setFriendToFriend(LouieB);
        SocialMediaTraversal sampleData = new SocialMediaTraversal();

        //add everyone to the databse
        sampleData.addPerson(YukiN);
        sampleData.addPerson(HaruhiS);
        sampleData.addPerson(Kyon);
        sampleData.addPerson(Asahina);
        sampleData.addPerson(EdE);
        sampleData.addPerson(AlE);
        sampleData.addPerson(RoyM);
        sampleData.addPerson(MasterC);
        sampleData.addPerson(NathanD);
        sampleData.addPerson(ElenaF);
        sampleData.addPerson(MaribelB);
        sampleData.addPerson(LouieB);

        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to Lowell Media");
        String answer;
        do {
            System.out.println("Do you want to create a profile (Enter Yes/No)");
           answer = scan.nextLine();

        }while (!answer.equalsIgnoreCase("yes") && !answer.equalsIgnoreCase("no"));

        /*
        ----------Make User Profile --------
         */
        if(answer.equalsIgnoreCase("yes")) {
            System.out.println("Please Enter a Name");
            String userName = scan.nextLine();
            System.out.println("Are you in a relationship (Enter Yes/No)");
            String status = scan.nextLine();
            boolean userStatus = false;
            if (status.equalsIgnoreCase("yes")) {
                userStatus = true;
            }

            UserObj newUser = new UserObj(userName, userStatus);
            System.out.println("Your Profile: ");
            System.out.println(newUser.toString());
            System.out.println("Thank You for making an Account");
            /*
            ----------Make a graph and add the user to it--------------
             */

           // sampleData.addPerson(newUser);
            /*
            ---------What can the user do------------
             */
            boolean boolStatus = false;
            int userNumInput = 0;
            Scanner scanInt = new Scanner(System.in);
            String stringInput;
            do {
                System.out.println();
                System.out.println("What do you want to do?  \n1-Find Friend \n2-Remove Friend \n3-Show Friend List \n4-Change Status \n5-CONTACT EMERGENCY \n6-Check If You're Alive " +
                        "\n7-Show Friend's List \n8-Exit ");
                userNumInput = scanInt.nextInt();

                switch (userNumInput)
                {
                    case 1:
                        System.out.println("Who are you looking for (Search by status)");
                        do {
                            System.out.println("Enter Status (Single/Relationship)");
                            status = scan.nextLine();
                        }while(!status.equalsIgnoreCase("single") && !status.equalsIgnoreCase("relationship"));
                        if (status.equalsIgnoreCase("single"))
                            boolStatus = false;
                        if(status.equalsIgnoreCase("relationship"))
                        {
                            boolStatus = true;
                        }
                        //display found possible list
                        System.out.println("Here are a list of possible friends:");
                        sampleData.findPossFriend(boolStatus);
                        do {
                            System.out.println("Who do you want to add (Enter Full Name)");
                            stringInput = scan.nextLine();
                            //adds the firend to user's list of friends
                        }while(!sampleData.containsNamePL(stringInput));
                        System.out.println(stringInput);
                        newUser.setFriendToFriend(sampleData.getFriendFromList(stringInput));
                        System.out.println("Added!!!!!");
                        break;
                    case 2:
                        do {
                            System.out.println("Who do you want to remove (Enter Full Name)");
                            stringInput = scan.nextLine();
                        }while(!newUser.inFirendList(stringInput));
                        newUser.removeFriend(newUser.getFriend(stringInput));
                        newUser.displayFriends();
                        break;
                    case 3:
                        System.out.println("Your Friend List:");
                        newUser.displayFriends();
                        break;
                    case 4:
                        newUser.changeStatus();
                        System.out.println("Your New Status");
                        System.out.println(newUser.getStatusString());
                        break;
                    case 5:
                        System.out.println("Contacting Everyone");
                        sampleData.contactEveryone(newUser);
                        System.out.println("Contacted all your friends");
                        sampleData.uncontactEveryone(newUser);
                        break;
                    case 6:System.out.println("Yes you're alive");
                        break;
                    case 7:
                        System.out.println("Your Friend's List");
                        System.out.println("Whose list do you want to view");
                        newUser.displayFriends();
                        do {
                            System.out.println("Enter a name");
                            stringInput = scan.nextLine();
                        }while(!newUser.inFirendList(stringInput));
                        newUser.getFriend(stringInput).displayFriends();
                        break;
                    default: System.out.println();
                        break;
                }

            }while(userNumInput >0 && userNumInput < 8 );
        }
        System.out.println("\nThanks for using Lowell Media");
        System.out.println("EXITING");
















    }
}
