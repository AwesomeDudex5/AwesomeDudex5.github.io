import java.util.*;
import java.lang.*;
import java.text.*;



/**
 * Created by Owner on 12/5/2015.
 * Lowell Batacan
 */
public class UserObj {
    private String name;
    private boolean contacted;
    private ArrayList<UserObj> friendList;
    private boolean status;

    //status: true = relationship, flase = single
    public UserObj(String inName,Boolean inStatus)
    {
        this.name = inName;
        this.contacted = false;
        this.status = inStatus;
        this.friendList = new ArrayList<>();
    }

    //Adds a friend to the list
    public boolean addFriend(UserObj newFriend)
    {
        return this.friendList.add(newFriend);
    }

    //Removes a friend from the list
    public boolean removeFriend( UserObj aFriend)
    {

        return this.friendList.remove(aFriend);
    }

    //Gets the name
    public String getName()
    {
        return this.name;
    }

    //Gets the Status
    public boolean getStatus()
    {
        return this.status;
    }

    public  String getStatusString()
    {
        String relationship = "Single";
        if(this.status == true)
            relationship = "In a Relationship";
        return relationship;
    }

    //get contacted status
    public boolean isContacted()
    {
        return this.contacted;
    }

    public  ArrayList<UserObj> getFriendList()
    {
        return this.friendList;
    }

    public boolean inFirendList(String userName)
    {
        boolean truthVal = false;
        for(UserObj user:this.friendList)
        {
            if(user.getName().equalsIgnoreCase(userName))
            {
                truthVal = true;
            }
        }
        return truthVal;
    }

    public UserObj getFriend(String userName)
    {
        UserObj foundUser = null;
        for(UserObj user: this.friendList)
        {
            if(user.getName().equalsIgnoreCase(userName))
            {
                foundUser = user;
            }
        }
        return foundUser;
    }


    //Checks if it is equal
    public boolean equals(UserObj user)
    {
        boolean truthVal = false;
        if(this.status == user.status  && this.name == user.name)
        {
            truthVal = true;
        }
        return truthVal;
    }

    public boolean isFriends(UserObj aUser)
    {
        boolean truthVal = false;
        if(this.friendList.contains(aUser) && aUser.friendList.contains(this))
        {
            truthVal = true;
        }
        return truthVal;
    }

    public void displayFriends()
    {
        for(UserObj user:this.friendList)
        {
            System.out.println(user);
        }
    }


    //Set Methods, Allow User to change or modify properties
    public  void  setName(String newName)
    {
        this.name = newName;
    }

    public void changeStatus()
    {
        if(this.status == true)
            this.status = false;
        else if(this.status == false)
            this.status = true;
    }

    public void contact()
    {
        this.contacted = true;
    }

    public void unContact() //THIS IS NOT A WORD
    {
        this.contacted = false;
    }

    public void setFriendToFriend(UserObj friend)
    {
        this.friendList.add(friend);
        friend.friendList.add(this);

    }


    //To String Method
    public String toString()
    {
        return "Name: " + this.name + " \nStatus: " + getStatusString();
    }






    }
