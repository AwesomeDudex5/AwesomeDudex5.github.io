
import java.io.*;
import  java.util.*;
/**
 * Created by Lowell Batacan on 12/2/2015.
 */
public class UndirectedGraph<T> extends DirectedGraph<T> implements ConnectedGraphInterface<T>
{



    public UndirectedGraph()
    {
        super();
    }


    public int getNumberOfEdges()
    {
        return super.getNumberOfEdges()/2;
    }

    public boolean addEdge(T begin, T end, double edgeWeight)
    {
        if(super.addEdge(begin, end, edgeWeight) && super.addEdge(end, begin, edgeWeight))
            return true;
        else
            return false;
    }

    public boolean addEdge(T begin, T end)
    {

        if( super.addEdge(begin, end) && super.addEdge(end, begin))
        {
         return true;
        }
        else
            return false;

    }

    public Stack<T> getTopologicalOrder()
    {
        Stack<T> stack = new Stack<>();
        try {
            stack =super.getTopologicalOrder();
        }
        catch(UnsupportedOperationException UOE)
        {
            System.out.println("Unsupported Operation Error");
        }
        return stack;
    }

    public boolean isConnected(T origin)
    {
        Queue<T> theQueue = super.getBreadthFirstTraversal(origin);
        if(theQueue.size() == super.getNumberOfVertices())
        {
            return true;
        }
        else
            return false;



    }



}
