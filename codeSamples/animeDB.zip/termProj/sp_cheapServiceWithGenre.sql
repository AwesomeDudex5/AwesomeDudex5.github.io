use animeDB;

#create a listing of the cheapest services that contains the most anime of that genre
drop procedure if exists cheapServicesWithGenre;
delimiter $$
create procedure cheapServicesWithGenre(genreIDD int(11))
begin

select distinct s.streamingID as streamingID, s.serviceName as serviceName,
s.cheapFee as fee, genretype.genreName, count(animegenre.genreID) as numOfAnime
from (
	select streamingservice.streamingID, streamingservice.serviceName, min(streamingservice.subscriptionFee) as cheapFee
    from streamingservice group by streamingservice.streamingID
	)as s
join anime on s.streamingID = anime.streamingID
join animegenre on anime.animeID = animegenre.animeID
join genretype on animegenre.genreID = genretype.genreID
where animegenre.genreID = genreIDD
order by fee asc
limit 1;


end $$
delimiter ; 

call cheapServicesWithGenre(1501);