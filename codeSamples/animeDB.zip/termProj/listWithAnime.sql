use animeDB;

#shows all the lists and users who have the same shared anime, taking anime as input
drop procedure if exists listWithAnime;
delimiter $$
create procedure listWithAnime( inputID int(11) )
begin

select distinct animelist.listID, animeuser.userID, animeuser.userName
from animeuser join userlist on animeuser.userID = userlist.userID
join animelist on userlist.listID = animelist.listID
join anime on animelist.animeID = anime.animeID
where anime.animeID = inputID;

end $$
delimiter ; 

call listWithAnime(1);
