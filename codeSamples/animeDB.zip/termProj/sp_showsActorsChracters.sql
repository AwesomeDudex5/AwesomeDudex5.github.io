use animeDB;

#produces a listing of voice actors and the characters they play and anime, based on the vaType (English or Japanese)
drop procedure if exists showActorsCharacters;
delimiter $$
create procedure showActorsCharacters( vaInput varchar(11))
begin

select employee.employeeID, employee.employeeName, anime.animeName, characters.characterName, voiceacting.vaType
from employee join voiceacting on employee.employeeID = voiceacting.employeeID
join characters on voiceacting.characterID = characters.characterID
join anime on characters.animeID = anime.animeID
where vaType = vaInput;

end $$
delimiter ; 

call showActorsCharacters('English');
