use animeDB;

#create a listing of licensors and their studio partners with licensors as input
drop procedure if exists licensorPartners;
delimiter $$
create procedure licensorPartners( inputID int(11) )
begin

select distinct licensors.licensorID, licensors.companyName, studios.studioName
from licensors join anime on licensors.licensorID = anime.licensorID
join studios on anime.studioID = studios.studioID
where licensors.licensorID = inputID;

end $$
delimiter ; 

call licensorPartners(6001);
