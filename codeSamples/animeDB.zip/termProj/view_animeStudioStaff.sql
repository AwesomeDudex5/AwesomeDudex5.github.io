use animeDB;

#to view the staff and studio who worked on an anime
create or replace view animeStudioStaff as
select  anime.animeID as animeID, anime.animeName as animeName, employee.employeeName as EMPNAME, jobrole.jobName ,studios.studioName
from anime join studios on anime.studioID = studios.studioID
join staff on studios.studioID = staff.studioID
join employee on staff.employeeID = employee.employeeID 
join jobrole on employee.jobID = jobrole.jobID
order by animeID asc;