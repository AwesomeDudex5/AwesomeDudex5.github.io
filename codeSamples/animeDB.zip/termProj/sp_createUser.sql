use animeDB;

#insert a new user into the anime user
#takes in a name and gender
drop procedure if exists createUser;
delimiter $$
create procedure createUser( username varchar(11), userGender varchar(1))
begin

declare newUserID int(11);

set newUserID = (select max(animeuser.userID) from animeuser) + 1;

insert into animeuser (userID, userName, gender, dateCreated) values
(newUserID, username, userGender, now());

select distinct * from animeuser;

end $$
delimiter ; 

call createUser('NuBot', 'm');
