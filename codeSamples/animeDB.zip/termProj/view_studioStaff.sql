use animeDB;

/*select distinct anime.animeName as Anime, studios.studioName as Studio
from anime join studios on anime.studioID = studios.studioID; */

#view for all staff with their corresponding job role and studios they worked at
create or replace view studioStaff as
select employee.employeeName as 'Emp Name', jobrole.jobName as 'Role',
studioName as 'Studio'
from jobrole join employee on jobrole.jobID = employee.jobID
join staff on employee.employeeID = staff.employeeID
join studios on staff.studioID = studios.studioID;

/*/*select employee.employeeName as 'Emp Name', jobrole.jobName as 'Role',
studios.studioName as 'Studio', studios.studioID
from jobrole inner join employee on jobrole.jobID = employee.jobID
inner join staff on employee.employeeID = staff.employeeID
inner join studios on staff.studioID = studios.studioID;

select distinct employee.employeeName as empName, jobrole.jobName as Job,studios.studioName as studioName
from studios join staff on studios.studioID = staff.studioID
join employee on staff.employeeID = employee.employeeID
left join jobrole on employee.jobID = jobrole.jobID;*/
