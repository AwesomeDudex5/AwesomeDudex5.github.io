use animeDB;

#changes the status of a userlist anime to watching or completed
drop procedure if exists updateAnimeStatus;
delimiter $$
create procedure updateAnimeStatus( userListID int(11), animeID int(2), changeStatus varchar (20))
begin

update animelist set status = changeStatus
where animelist.listID = userlistID and animelist.animeID = animeID;

end $$
delimiter ; 

call updateAnimeStatus(500, 1, 'complete');
