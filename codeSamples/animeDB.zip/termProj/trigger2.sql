/* checks if the username is avilable returns null if its not*/
DELIMITER $$
create trigger check_user_availability
before insert on animeuser for each row
begin
	set @userID = new.userID;
    set @userName = new.userName;
	select userName into @user_name from animeuser where animeuser.userID = @userID;
    /*It should set username null but does not work*/
    if(@user_name like @user_name)then
		set new.userName = 'NULL';
	end if;
end $$