
drop database if exists animeDB;

create database animeDB; 

use animeDB;

create table anime(
	animeID integer not null,
    animeName varchar(50) not null,
    episodeNum integer default 0,
    dateAired date,
    licensorID integer NULL,
    streamingID integer NULL,
    studioID integer NULL,
    primary key(animeID)
)engine=innodb;

create table licensors(
	licensorID integer not null,
    companyName varchar(50) not null,
    city varchar(30) not null,
    state varchar(2) not null,
    country varchar(20) not null,
    primary key(licensorID)
)engine=innodb;

create table streamingService(
	streamingID integer not null,
    serviceName varchar(20) not null,
	countryAvailable varchar(20) not null,
    subscriptionFee double null,
    primary key(streamingID)
)engine=innodb;

create table animeUser(
	userID integer not null,
    userName varchar(10) not null,
    gender varchar(6) not null,
    dateCreated date,
    primary key(userID)
)engine=innodb;

/*connects the user with their list*/
create table userList(
	listID integer not null,
    userID integer null,
    primary key(listID)
)engine=innodb;

/*allows the list to have anime without redundant columns*/
create table animeList(
	listID integer not null,
    animeID integer not null,
    dateAdded date,
    primary key(listID)
)engine=innodb;

/* holds all the genres types*/
create table genreType(
	genreID integer not null,
    genreName varchar(10) not null,
    primary key(genreID)
)engine=innodb;

/*contains the anime and its genres*/
create table animeGenre(
	genreID integer not null,
    animeID integer not null,
    primary key(genreID)
)engine=innodb;

create table characters(
characterID integer not null,
animeID integer not null,
characterName varchar(30),
gender varchar(6),
primary key(characterID)
)engine=innodb;

create table studios(
studioID integer not null,
studioName varchar(20),
dateFounded year,
primary key(studioID)
)engine = innodb;

create table staff(
employeeID integer not null,
studioID integer null,
timeWorked integer,
primary key(employeeID)
)engine = innodb;

create table voiceActing(
employeeID integer not null,
characterID integer null,
vaType varchar(9) not null,
primary key(employeeID)
)engine = innodb;

create table employee(
employeeID integer not null,
employeeFirstName varchar(15),
employeeLastName varchar(15),
jobID integer null,
primary key(employeeID)
)engine = innodb;

create table jobRole(
jobID integer not null,
jobName varchar (15),
jobDescription varchar (15),
primary key(jobID)
)engine = innodb;

alter table employee
add constraint fk_employee_1
foreign key (jobID) references jobRole (jobID);

alter table staff
add constraint fk_staff_1
foreign key (employeeID) references employee (employeeID);

alter table staff
add constraint fk_staff_2
foreign key (studioID) references studios (studioID);

alter table voiceActing
add constraint fk_voiceActing_1
foreign key (employeeID) references employee (employeeID);

alter table voiceActing
add constraint fk_voiceActing_2
foreign key (characterID) references characters (characterID);

alter table anime
add constraint fk_anime_1
foreign key (licensorID) references licensors (licensorID);

alter table anime
add constraint fk_anime_2
foreign key (streamingID) references streamingService (streamingID);

alter table anime
add constraint fk_anime_3
foreign key (studioID) references studios (studioID);

alter table characters 
add constraint fk_characters_1
foreign key (animeID) references anime (animeID);

alter table animeGenre
add constraint fk_animeGenre_1
foreign key (genreID) references genreType (genreID);

alter table animeGenre
add constraint fk_animeGenre_2
foreign key (animeID) references anime (animeID);

alter table animeList
add constraint fk_animeList_1
foreign key (animeID) references anime (animeID);

alter table animeList
add constraint fk_animeList_2
foreign key (listID) references userList (listID);

alter table userList
add constraint fk_userList_1
foreign key (userID) references animeUser (userID);






