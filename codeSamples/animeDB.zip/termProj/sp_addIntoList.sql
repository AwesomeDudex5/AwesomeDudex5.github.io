use animeDB;

select distinct animelist.listID, animeName from animelist join anime on animelist.animeID = anime.animeID;

#insert an anime into a users animeList
drop procedure if exists addIntoList;
delimiter $$
create procedure addIntoList( listIDADD int(11), animeIDADD int(11))
begin

insert into animelist (listID, animeID, dateAdded) values
(listIDADD, animeIDADD, now())
on duplicate key update animeID = animeIDADD;

select distinct animelist.listID, animeName from animelist join anime on animelist.animeID = anime.animeID;

end $$
delimiter ; 

call addIntoList(503, 27);



