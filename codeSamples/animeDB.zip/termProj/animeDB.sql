
drop database if exists animeDB;

create database animeDB; 

use animeDB;

create table anime(
	animeID integer not null,
    animeName varchar(50) not null,
	dateAired year,
    episodeNum integer not null,
	studioID integer NULL,
    licensorID integer NULL,
    streamingID integer NULL,
    primary key(animeID)
)engine=innodb;

create table licensors(
	licensorID integer not null,
    companyName varchar(50) not null,
    city varchar(30) not null,
    state varchar(2) not null,
    country varchar(20) not null,
    primary key(licensorID)
)engine=innodb;

create table streamingService(
	streamingID integer not null,
    serviceName varchar(20) not null,
    subscriptionFee double null,
    primary key(streamingID)
)engine=innodb;

create table animeUser(
	userID integer not null,
    userName varchar(15) not null,
    gender varchar(6) not null,
    dateCreated date,
    primary key(userID)
)engine=innodb;

/*connects the user with their list*/
create table userList(
	listID integer not null,
    userID integer null,
    primary key(listID)
)engine=innodb;

/*allows the list to have anime without redundant columns*/
create table animeList(
	listID integer not null,
    animeID integer not null,
    dateAdded date
)engine=innodb;

/* holds all the genres types*/
create table genreType(
	genreID integer not null,
    genreName varchar(15) not null,
    primary key(genreID)
)engine=innodb;

/*contains the anime and its genres*/
create table animeGenre(
	genreID integer not null,
    animeID integer not null
)engine=innodb;

create table characters(
characterID integer not null,
animeID integer not null,
characterName varchar(30),
gender varchar(6),
primary key(characterID)
)engine=innodb;

create table studios(
studioID integer not null,
studioName varchar(20),
dateFounded year,
primary key(studioID)
)engine = innodb;

create table staff(
employeeID integer not null,
studioID integer null,
timeWorked year,
primary key(employeeID)
)engine = innodb;

create table voiceActing(
employeeID integer not null,
characterID integer null,
vaType varchar(9) not null,
primary key(employeeID)
)engine = innodb;

create table employee(
employeeID integer not null,
employeeName varchar(30),
jobID integer null,
primary key(employeeID)
)engine = innodb;

create table jobRole(
jobID integer not null,
jobName varchar (15),
jobDescription varchar (35),
primary key(jobID)
)engine = innodb;

alter table employee
add constraint fk_employee_1
foreign key (jobID) references jobRole (jobID);

alter table staff
add constraint fk_staff_1
foreign key (employeeID) references employee (employeeID);

alter table staff
add constraint fk_staff_2
foreign key (studioID) references studios (studioID);

alter table voiceActing
add constraint fk_voiceActing_1
foreign key (employeeID) references employee (employeeID);

alter table voiceActing
add constraint fk_voiceActing_2
foreign key (characterID) references characters (characterID);

alter table anime
add constraint fk_anime_1
foreign key (licensorID) references licensors (licensorID);

alter table anime
add constraint fk_anime_2
foreign key (streamingID) references streamingService (streamingID);

alter table anime
add constraint fk_anime_3
foreign key (studioID) references studios (studioID);

alter table characters 
add constraint fk_characters_1
foreign key (animeID) references anime (animeID);

alter table animeGenre
add constraint fk_animeGenre_1
foreign key (genreID) references genreType (genreID);

alter table animeGenre
add constraint fk_animeGenre_2
foreign key (animeID) references anime (animeID);

alter table animeList
add constraint fk_animeList_1
foreign key (animeID) references anime (animeID);

alter table animeList
add constraint fk_animeList_2
foreign key (listID) references userList (listID);

alter table userList
add constraint fk_userList_1
foreign key (userID) references animeUser (userID);

use animeDB;
DELETE FROM anime;
DELETE FROM animegenre;
DELETE FROM animelist;
DELETE FROM animeuser;
DELETE FROM characters;
DELETE FROM employee;
DELETE FROM genretype;
DELETE FROM jobrole;
DELETE FROM licensors;
DELETE FROM staff;
DELETE FROM streamingservice;
DELETE FROM studios;
DELETE FROM userlist;
DELETE FROM voiceacting;


# Load records into the tables. There should be no warnings.


LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\user.txt' INTO TABLE animeuser
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;

LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\userlist.txt' INTO TABLE userlist
          FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;

LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\jobrole.txt' INTO TABLE jobrole
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;


LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\employees.txt' INTO TABLE employee
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;


LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\genretype.txt' INTO TABLE genretype
          FIELDS TERMINATED BY ','  TERMINATED BY '"' optionally ENCLOSED BY '"' LINES TERMINATED BY '\r\n' ;
SHOW WARNINGS LIMIT 10;



LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\licensors.txt' INTO TABLE licensors
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;



LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\streamingservice.txt' INTO TABLE streamingservice
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;

LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\studios.txt' INTO TABLE studios
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;




LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\anime.txt' INTO TABLE anime
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;



LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\animelist.txt' INTO TABLE animelist
          FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;



LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\genre.txt' INTO TABLE animegenre
          FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;

LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\characters.txt' INTO TABLE characters
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;

LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\voiceacting.txt' INTO TABLE voiceacting
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;

LOAD DATA LOCAL INFILE 'C:\\Users\\Owner\\Desktop\\Senior2017\\database\\termProj\\staff.txt' INTO TABLE staff
          FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n';
SHOW WARNINGS LIMIT 10;
