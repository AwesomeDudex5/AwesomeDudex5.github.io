use animeDB;

#create a view that shows the most popular genre each voice actor plays
create or replace view mostPopularGenreForVA as
select distinct employeeName, vaType ,genreName, count(animegenre.genreID)
from employee join voiceacting on employee.employeeID = voiceacting.employeeID
join characters on voiceacting.characterID = characters.characterID
join anime on characters.animeID = anime.animeID
join animegenre on anime.animeID = animegenre.animeID
join genretype on animegenre.genreID = genretype.genreID
group by employeeName;
