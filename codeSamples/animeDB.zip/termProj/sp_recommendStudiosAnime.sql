use animeDB;

#recommends anime based on the studios that worked on an anime as input
drop procedure if exists recommendStudiosAnime;
delimiter $$
create procedure recommendStudiosAnime( animeInput int(11))
begin

declare studioInput int(11);
set studioInput = (select studios.studioID from studios join anime on studios.studioID = anime.studioID
where anime.animeID = animeInput);

select anime.animeID as 'Anime ID', studios.studioName as 'Studio Name', anime.animeName as 'Anime Name',
 anime.dateAired as 'Date Aired' from studios join anime on studios.studioID = anime.studioID
 where studios.studioID = studioInput;

end $$
delimiter ; 

call recommendStudiosAnime(4);
