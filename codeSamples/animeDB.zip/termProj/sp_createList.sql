use animeDB;

#make a new list for a user as input
drop procedure if exists createList;
delimiter $$
create procedure createList( inputUserID int(11))
begin

declare newListID int(11);
set newListID = (select max(userList.listID) from userlist) + 1;

insert into userlist (listID, userID) values
(newListID, inputUserID);

select distinct * from userlist;

end $$
delimiter ; 

call createList(50005);
