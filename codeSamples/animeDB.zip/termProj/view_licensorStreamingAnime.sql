use animeDB;

#create a view of licensors and streaming services, along with the subscription fee, and the anime they own
create or replace view licensorStreamingAnime as
select distinct anime.animeName, licensors.companyName, streamingservice.serviceName, 
streamingservice.subscriptionFee
from licensors join anime on licensors.licensorID = anime.licensorID
join streamingservice on anime.streamingID = streamingservice.streamingID
group by animeName;