use animeDB;

select distinct animelist.listID, animeName from animelist join anime on animelist.animeID = anime.animeID;

#insert an anime into a users animeList
drop procedure if exists deleteFromList;
delimiter $$
create procedure deleteFromList( listIDD int(11), animeIDD int(11))
begin

delete from animelist
where animeID = animeIDD
and animelist.listID = listIDD;

select distinct animelist.listID, animeName from animelist join anime on animelist.animeID = anime.animeID;

end $$
delimiter ; 

call deleteFromList(503, 27);