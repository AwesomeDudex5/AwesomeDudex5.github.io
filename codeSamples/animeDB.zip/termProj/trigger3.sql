/*it basically updates staff info if they have 
changed where they want to work for example switching studios*/
DELIMITER $$
create trigger before_staff_update
before update on staff
for each row
begin
	insert into staff
    set action = 'update',
    employeeID = OLD.employeeID,
    studioID = OLD.studioID,
    changedat = NOW();
end $$
