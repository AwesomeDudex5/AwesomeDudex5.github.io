use animeDB;

#create a view of studios and the number of anime they made
create or replace view animeMade as
select distinct studios.studioID, studios.studioName, count(anime.studioID) as numOfAnimeMade
from anime join studios on anime.studioID = studios.studioID
group by studioName
order by studioID asc;