use animeDB;

#shows users who have watched the same anime as you
drop procedure if exists usersWithSameAnime;
delimiter $$
create procedure usersWithSameAnime( userInput int(11))
begin

select distinct animeuser.userID, animeuser.userName, userlist.listID
from animeuser join userlist on animeuser.userID = userlist.userID
join animelist on userlist.listID = animelist.listID
group by animeuser.userID
having count(animelist.animeID) > 1;

end $$
delimiter ; 

call usersWithSameAnime(50001);
