DELIMITER $$
create trigger check_username_availability
before insert on anime for each row
begin
	set @animeID = new.animeID;
    set @dateAired = new.dateAired;
    set @studioID = new.studioID;
    select dateFounded into @date_founded from studios where studios.studioID = @studioID;
    select dateAired into @date_aired from anime where anime.animeID = @animeID;
    if @date_founded >= @dateAired then
		set new.dateAired = NULL ; /* cant add date of anime if is before the studio creation date 
									so we set it null*/
	end if;
end $$

