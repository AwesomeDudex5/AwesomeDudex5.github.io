use animeDB;

#create a listing of recommendations based on genre
drop procedure if exists recommendByGenre;
delimiter $$
create procedure recommendByGenre(genreIDD int(11))
begin

select anime.animeID as ID, anime.animeName as Name, genretype.genreName as genre
from anime join animegenre on anime.animeID = animegenre.animeID
join genretype on animegenre.genreID = genretype.genreID
where animegenre.genreID = genreIDD;

end $$
delimiter ; 

call recommendByGenre(1501);